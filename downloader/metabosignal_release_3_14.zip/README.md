To install with vignettes: devtools::install_github ("AndreaRMICL/MetaboSignal", build_vignettes = TRUE)

If you get the following dependency error: "ERROR: dependency org.Hs.eg.db is not
available for package MetaboSignal", install org.Hs.eg.db individually before
installing MetaboSignal

To see a workflow example: browseVignettes("MetaboSignal")

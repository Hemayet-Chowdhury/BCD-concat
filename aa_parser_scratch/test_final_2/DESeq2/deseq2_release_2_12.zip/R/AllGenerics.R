#' @rdname dispersionFunction
#' @export
setGeneric("dispersionFunction", function(object) standardGeneric("dispersionFunction"))

#' @rdname dispersionFunction
#' @export
setGeneric("dispersionFunction<-", function(object,value) standardGeneric("dispersionFunction<-"))

#' @rdname dispersions
#' @export
setGeneric("dispersions", function(object) standardGeneric("dispersions"))

#' @rdname dispersions
#' @export
setGeneric("dispersions<-", function(object, value) standardGeneric("dispersions<-"))

#' @rdname normalizationFactors
#' @export
setGeneric("normalizationFactors", function(object) standardGeneric("normalizationFactors"))

#' @rdname normalizationFactors
#' @export
setGeneric("normalizationFactors<-", function(object,value) standardGeneric("normalizationFactors<-"))

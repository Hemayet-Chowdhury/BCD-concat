## shiny app for interactive use of scater
## Davis McCarthy
## 18 November 2015

scater_interactive <- function(object) {
    
    
}
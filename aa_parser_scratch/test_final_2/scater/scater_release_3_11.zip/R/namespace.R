#' @useDynLib scater, .registration=TRUE
#' @importFrom Rcpp sourceCpp
#' @import methods
NULL

